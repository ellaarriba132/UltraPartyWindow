from bsSpaz import *
import bsSpaz
import bs
import bsUtils
import weakref
import random
import math
import time
import base64
import os,json
import bsInternal
import getPermissionsHashes as gph
from thread import start_new_thread

class PermissionEffect(object):
    def __init__(self, owner=None, prefix='', prefixColor=(1, 1, 1), prefixAnim={0: (0, 0, 0), 10: (1, 1, 1)}, prefixAnimate=True, particles=True, type='spark'):
        self.owner = owner
        self.particles_type = type
        self.prefix_string = prefix
        def a():
            self.emit()
        if self.owner is not None:
            if particles: self.timer = bs.Timer(10, bs.Call(a), repeat=True)
            m = bs.newNode('math', owner=self.owner, attrs={'input1': (0, 1.55, 0), 'operation': 'add'})
            self.owner.connectAttr('position', m, 'input2')
            self.prefix = bs.newNode('text', owner=self.owner,
                                     attrs={'text': self.prefix_string, 'inWorld': True, 'shadow': 0.3, 'flatness': 1.0,
                                            'color': prefixColor, 'scale': 0.5554, 'hAlign': 'center', 'maxWidth': 100})
            m.connectAttr('output', self.prefix, 'position')
            if prefixAnimate: bsUtils.animateArray(self.prefix, 'color', 3, prefixAnim, True)

    def emit(self):
        if self.owner.exists():
            bs.emitBGDynamics(position=tuple([self.owner.position[i]+random.uniform(-0.3,0.3) for i in range(3)]),
                              velocity=(0, 0, 0),
                              count=10,
                              scale=0.6,
                              spread=0.05,
                              chunkType=self.particles_type)

class rankEffect(object):
    def __init__(self,position = (0,1,0),owner = None,prefix = 'ADMIN',prefixColor = (1,1,1),prefixAnim = {0:(1,1,1),500:(0.5,0.5,0.5)},prefixAnimate = True,particles = True):
        self.position = position
        self.owner = owner
        
         #  https://github.com/imayushsaini/Bombsquad-modded-server-Mr.Smoothy

            
        #prefix
        m = bs.newNode('math', owner=self.owner, attrs={'input1': (0, 1.65, 0), 'operation': 'add'})
        self.owner.connectAttr('position', m, 'input2')
        
        self._Text = bs.newNode('text',
                                      owner=self.owner,
                                      attrs={'text':prefix, #prefix text
                                             'inWorld':True,
                                             'shadow':1.2,
                                             'flatness':1.0,
                                             'color':(1,1,1),
                                             'scale':0.0,
                                             'hAlign':'center'})
                                             
        m.connectAttr('output', self._Text, 'position')
        
        node = bs.animate(self._Text, 'scale', {0: 0.0, 1000: 0.01}) #smooth prefix spawn

def __init__(self,color=(1,1,1),highlight=(0.5,0.5,0.5),character="Spaz",player=None,powerupsExpire=True):
        """
        Create a spaz for the provided bs.Player.
        Note: this does not wire up any controls;
        you must call connectControlsToPlayer() to do so.
        """
        #https://github.com/imayushsaini/Bombsquad-Mr.Smoothy-Admin-Powerup-Server
        # convert None to an empty player-ref
        if player is None: player = bs.Player(None)
        
        Spaz.__init__(self,color=color,highlight=highlight,character=character,sourcePlayer=player,startInvincible=True,powerupsExpire=powerupsExpire)
        self.lastPlayerAttackedBy = None # FIXME - should use empty player ref
        self.lastAttackedTime = 0
        self.lastAttackedType = None
        self.heldCount = 0
        self.lastPlayerHeldBy = None # FIXME - should use empty player ref here
        self._player = player
        
        
        
        profiles = []
        profiles = self._player.getInputDevice()._getPlayerProfiles()
        
        stats = False# have it turned off, logs kills not rank

        if stats:
            if os.path.exists(bs.getEnvironment()['systemScriptsDirectory'] + "/stats.json"):
                f = open(bs.getEnvironment()['systemScriptsDirectory'] + "/stats.json", "r")
                #aid = str(pats[str(player.get_account_id())]["rank"])
                jd = {}
                try:
                    jd = json.loads(f.read())
                    aid = str(self.sourcePlayer.get_account_id())
                except Exception:
                    bs.printException()
                if aid in jd:
                    kill = jd[aid]["kills"]
                    if stats:
                        rankEffect(owner=self.node, prefix='#'+str(jd[str(player.get_account_id())]["kills"]),prefixAnim = {0: (1,1,1)})
                    else:
                        rankEffect(owner=self.node, prefix='?',prefixAnim = {0: (1,1,1)})

        playeraccountid=self._player.get_account_id()

        if playeraccountid in gph.ownersHashes:
            #self.node.handleMessage(bs.PowerupMessage(powerupType = 'punchs'))
            #self.node.color = (9,9,9)
            #self.node.handleMessage('celebrate',5000)
            self.modpack = bs.NodeActor(bs.newNode('text',
                                                  attrs={'vAttach':'bottom',
                                                         'hAttach':'right',
                                                         'hAlign':'right',
                                                         'color':(1,1,1),
                                                         'flatness':1.0,
                                                         'shadow':1.0,
                                                         'scale':0.85,
                                                         'position':(-200,5),
                                                         'text':u'\ue048Owners Are Playing\ue048'}))

        if playeraccountid in gph.ownersHashes:
            self._inv = bs.Timer(100, bs.Call(lambda self: bs.emitBGDynamics(
                     position = self.node.position,
                     count = 1, chunkType='spark',
                     scale=0.3, spread=0.01) if self.node.exists() else None, self), repeat = True)