adminHashes = []
vipHashes = []
banlist = ['']
topperslist = []
effectCustomers = {}
customlist = {}
ownerHashes = ['pb-IF4xVUg4FA=='] # aqui papu / es mi id no me quites el owner porfa xd
surroundingObjectEffect = []
sparkEffect = []
smokeEffect = []
scorchEffect = [] 
distortionEffect = []
glowEffect = [] 
iceEffect=[]
slimeEffect = []
metalEffect = []
dragonHashes = []
customtagHashes=[]

#donot change the order of the list
#to enable/disable commands and effects for top 5 players goto settings.py

# LEEME!!!!!!!


"""
en el juego ve hasta
ajustes → avanzado → ingresar codigo → escribe esto "getaccountid"
ignorando las comillas claro

y copeas y pegas el pb-id en ownerHashes o cualquier otro
es importante que el pb-id este dentro de comillas simples 
ejemplo:
		'pb-IF4xVUg4FA=='


"""

