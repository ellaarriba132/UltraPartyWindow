"""
|BySempaiUwU

"""

# | bsPowerup.py | PowerupsOptions

lightOnPowerups = True 

timerDisappearRance = True

shieldOnPowerups = False

textOnPowerups = True

# | bsBomb.py.py | BombsOptions

trailSparks = False

lightOnBombs = True

prefixOnBombs = True

# | bsSpaz.py | spazOptions

lightPlayerColor = False

animateColorLights = False

HPstatus = False

# | bsGame.py | Welcome

welcomeToMesage = True


# |ExtraEffectsOnBombs

animateColor = False

changeColorDiley = True

# *END*
