# -*- coding: utf-8 -*-
import bs
import bsUtils
import weakref
import random
import math
import time
import base64
import os,json
import bsInternal
import getPermissionsHashes as gph
from thread import start_new_thread
#from VirtualHost import DB_Handler,Language,MainSettings,_execSimpleExpression
import bsSpaz
from bsSpaz import _BombDiedMessage,_CurseExplodeMessage,_PickupMessage,_PunchHitMessage,gBasePunchCooldown,gBasePunchPowerScale,gPowerupWearOffTime,PlayerSpazDeathMessage,PlayerSpazHurtMessage
#from codecs import BOM_UTF8
import settings
import rank
reload(rank)

class PermissionEffect(object):
    def __init__(self,position = (0,2,0),owner = None,kd=0.0,kills=0,prank=0,prefix = 'sempai',prefixColor = (1,1,1),prefixAnim = {0:(1,1,1),500:(0.5,0.5,0.5)},prefixAnimate = True, particles = True, type = 1, footprints = True):
        self.position = position
        self.owner = owner
        
       

        
        def a():
            self.emit()
            
        #particles    
        if particles:
            self.timer = bs.Timer(10,bs.Call(a),repeat = True)
            
        #prefix
        if type == 1:
            m = bs.newNode('math', owner=self.owner, attrs={'input1': (0, 1.8, 0), 'operation': 'add'})
        elif type == 2:
            m = bs.newNode('math', owner=self.owner, attrs={'input1': (0, 1.5, 0), 'operation': 'add'})
        elif type == 3:
            m = bs.newNode('math', owner=self.owner, attrs={'input1': (0, 2.0, 0), 'operation': 'add'})
        else:
            m = bs.newNode('math', owner=self.owner, attrs={'input1': (0, 1.3, 0), 'operation': 'add'})
        self.owner.connectAttr('position', m, 'input2')

        # n = bs.newNode('math', owner=self.owner, attrs={'input1': (0, 1, 0), 'operation': 'add'})
        # self.owner.connectAttr('position', n, 'input2')
        
        self._Text = bs.newNode('text',
                                      owner=self.owner,
                                      attrs={'text':prefix, #prefix text
                                             'inWorld':True,
                                             'shadow':1.2,
                                             'flatness':1.0,
                                             'color':prefixColor,
                                             'scale':0.0,
                                             'hAlign':'center'})
        # self._kd = bs.newNode('text',
        #                               owner=self.owner,
        #                               attrs={'text':'AYUSH', #prefix text
        #                                      'inWorld':True,
        #                                      'shadow':1.2,
        #                                      'flatness':1.0,
        #                                      'color':(0,2,1),
        #                                      'scale':0.0,
        #                                      'hAlign':'center'})
                                             
        m.connectAttr('output', self._Text, 'position')
        # n.connectAttr('output', self._kd, 'position')
        
        bs.animate(self._Text, 'scale', {0: 0.0, 1000: 0.00778}) #smooth prefix spawn
        
        #animate prefix
        if prefixAnimate:
            bsUtils.animateArray(self._Text, 'color',3, prefixAnim,True) #animate prefix color
        
    def emit(self):
        if self.owner.exists():
            vel = 4
            bs.emitBGDynamics(position=(self.owner.torsoPosition[0]-0.25+random.random()*0.5,self.owner.torsoPosition[1]-0.25+random.random()*0.5,self.owner.torsoPosition[2]-0.25+random.random()*0.5),
                              velocity=((-vel+(random.random()*(vel*2)))+self.owner.velocity[0]*2,(-vel+(random.random()*(vel*2)))+self.owner.velocity[1]*4,(-vel+(random.random()*(vel*2)))+self.owner.velocity[2]*2),
                              count=10,
                              scale=0.4,
                              spread=0.1,
                              chunkType='spark',
                              tendrilType='thinSmoke')
                              #emitType = 'stickers')


class kdpronoobtag(object):
    def __init__(self,position = (0,2,0),owner = None,kd=0.0,kills=0,prefix = ' ',prefixColor = (1,1,1),prefixAnim = {0:(1,1,1),500:(0.5,0.5,0.5)},prefixAnimate = False,particles = True):
        self.position = position
        self.owner = owner
        
       

        
        def a():
            self.emit()
            
        #particles    
        if kd>1.1:
            self.timer = bs.Timer(10,bs.Call(a),repeat = True)
            
        #prefix
        m = bs.newNode('math', owner=self.owner, attrs={'input1': (0, 2.0, 0), 'operation': 'add'})
        self.owner.connectAttr('position', m, 'input2')
        if kd>1.1:      #customize here the criteria for being noob or pro     like change to kd>0.7  or kd>2.0 or making it more tough
            prefix=''
            prefixColor=(0,1,0)
        if kd<0.2:
            prefix=''
            prefixColor=(1,0,0)
        if kills==0:
            prefix=''
            prefixColor=(1,1,0)
        # n = bs.newNode('math', owner=self.owner, attrs={'input1': (0, 1, 0), 'operation': 'add'})
        # self.owner.connectAttr('position', n, 'input2')
        
        self._Text = bs.newNode('text',
                                      owner=self.owner,
                                      attrs={'text':prefix, #prefix text
                                             'inWorld':True,
                                             'shadow':0.7,
                                             'flatness':1.0,
                                             'color':prefixColor,
                                             'scale':0.0,
                                             'hAlign':'center'})
        
                                             
        m.connectAttr('output', self._Text, 'position')
        # n.connectAttr('output', self._kd, 'position')
        
        bs.animate(self._Text, 'scale', {0: 0.0, 1000: 0.00778}) #smooth prefix spawn
        
        #animate prefix
        if prefixAnimate:
            bsUtils.animateArray(self._Text, 'color',3, prefixAnim,True) #animate prefix color
        
    def emit(self):
        if self.owner.exists():
            vel = 4
            bs.emitBGDynamics(position=(self.owner.torsoPosition[0]-0.25+random.random()*0.5,self.owner.torsoPosition[1]-0.25+random.random()*0.5,self.owner.torsoPosition[2]-0.25+random.random()*0.5),
                              velocity=((-vel+(random.random()*(vel*2)))+self.owner.velocity[0]*2,(-vel+(random.random()*(vel*2)))+self.owner.velocity[1]*4,(-vel+(random.random()*(vel*2)))+self.owner.velocity[2]*2),
                              count=10,
                              scale=0.3+random.random()*1.1,
                              spread=0.2,
                              chunkType='sweat')
                              #emitType = 'stickers')

ub=[]
class SurroundBallFactory(object):
    def __init__(self):
        self.bonesTex = bs.getTexture("powerupCurse")
        self.bonesModel = bs.getModel("bonesHead")
        self.bearTex = bs.getTexture("bearColor")
        self.bearModel = bs.getModel("bearHead")
        self.aliTex = bs.getTexture("aliColor")
        self.aliModel = bs.getModel("aliHead")
        self.b9000Tex = bs.getTexture("cyborgColor")
        self.b9000Model = bs.getModel("cyborgHead")
        self.frostyTex = bs.getTexture("frostyColor")
        self.frostyModel = bs.getModel("frostyHead")
        self.cubeTex = bs.getTexture("crossOutMask")
        self.cubeModel = bs.getModel("powerup")
        self.botsitoModel = bs.getModel("bomb")
        self.botsitoTex = bs.getTexture("fuse")
        try:
            self.mikuModel = bs.getModel("operaSingerHead")
            self.mikuTex = bs.getTexture("operaSingerColor")
        except:bs.PrintException()


        self.ballMaterial = bs.Material()
        self.impactSound = bs.getSound("impactMedium")
        self.ballMaterial.addActions(actions=("modifyNodeCollision", "collide", False))


class SurroundBall(bs.Actor):
    def __init__(self, spaz, shape="bones"):
        if spaz is None or not spaz.isAlive():
            return

        bs.Actor.__init__(self)

        self.spazRef = weakref.ref(spaz)

        factory = self.getFactory()

        s_model, s_texture = {
            "bones": (factory.bonesModel, factory.bonesTex),
            "bear": (factory.bearModel, factory.bearTex),
            "ali": (factory.aliModel, factory.aliTex),
            "b9000": (factory.b9000Model, factory.b9000Tex),
            "miku": (factory.mikuModel, factory.mikuTex),
            "frosty": (factory.frostyModel, factory.frostyTex),
            "RedCube": (factory.cubeModel, factory.cubeTex)
            "bot": (factory.botsitoModel, factory.botsitoTex)
        }.get(shape, (factory.bonesModel, factory.bonesTex))

        self.node = bs.newNode("prop",
                               attrs={"model": s_model,
                                      "body": "sphere",
                                      "colorTexture": s_texture,
                                      "reflection": "soft",
                                      "modelScale": 0.5,
                                      "bodyScale": 0.1,
                                      "density": 0.1,
                                      "reflectionScale": [0.15],
                                      "shadowSize": 0.6,
                                      "position": spaz.node.position,
                                      "velocity": (0, 0, 0),
                                      "materials": [bs.getSharedObject("objectMaterial"), factory.ballMaterial]
                                      },
                               delegate=self) 

        self.surroundTimer = None
        self.surroundRadius = 1.0
        self.angleDelta = math.pi / 12.0
        self.curAngle = random.random() * math.pi * 2.0
        self.curHeight = 0.0
        self.curHeightDir = 1
        self.heightDelta = 0.2
        self.heightMax = 1.0
        self.heightMin = 0.1
        self.initTimer(spaz.node.position)

    def getTargetPosition(self, spazPos):
        p = spazPos
        pt = (p[0] + self.surroundRadius * math.cos(self.curAngle),
              p[1] + self.curHeight,
              p[2] + self.surroundRadius * math.sin(self.curAngle))
        self.curAngle += self.angleDelta
        self.curHeight += self.heightDelta * self.curHeightDir
        if self.curHeight > self.heightMax or self.curHeight < self.heightMin:
            self.curHeightDir = -self.curHeightDir

        return pt

    def initTimer(self, p):
        self.node.position = self.getTargetPosition(p)
        self.surroundTimer = bs.Timer(30, bs.WeakCall(self.circleMove), repeat=True)

    def circleMove(self):
        spaz = self.spazRef()
        if spaz is None or not spaz.isAlive() or not spaz.node.exists():
            self.handleMessage(bs.DieMessage())
            return
        p = spaz.node.position
        pt = self.getTargetPosition(p)
        pn = self.node.position
        d = [pt[0] - pn[0], pt[1] - pn[1], pt[2] - pn[2]]
        speed = self.getMaxSpeedByDir(d)
        self.node.velocity = speed

    @staticmethod
    def getMaxSpeedByDir(direction):
        k = 7.0 / max((abs(x) for x in direction))
        return tuple(x * k for x in direction)

    def handleMessage(self, m):
        bs.Actor.handleMessage(self, m)
        if isinstance(m, bs.DieMessage):
            if self.surroundTimer is not None:
                self.surroundTimer = None
            self.node.delete()
        elif isinstance(m, bs.OutOfBoundsMessage):
            self.handleMessage(bs.DieMessage())

    def getFactory(cls):
        activity = bs.getActivity()
        if activity is None: raise Exception("no current activity")
        try:
            return activity._sharedSurroundBallFactory
        except Exception:
            f = activity._sharedSurroundBallFactory = SurroundBallFactory()
            return f
id='pb-IF5VUhEABA=='

class Enhancement(bs.Actor):
    def __init__(self, spaz, player):
        bs.Actor.__init__(self)
        self.sourcePlayer = player
        self.spazRef = weakref.ref(spaz)
        self.spazNormalColor = spaz.node.color
        self.Decorations = []
        self.Enhancements = []
        self._powerScale = 1.0
        self._armorScale = 1.0
        self._lifeDrainScale = None
        self._damageBounceScale = None
        self._remoteMagicDamge = False
        self._MulitPunch = None
        self._AntiFreeze = 1.0
        self.fallWings = 0
        
        self.checkDeadTimer = None
        self._hasDead = False
        self.light = None

	flag = 0
        profiles = []
        profiles = self.sourcePlayer.getInputDevice()._getPlayerProfiles()  


	cl_str = self.sourcePlayer.get_account_id()
	clID = self.sourcePlayer.getInputDevice().getClientID()
	#print cl_str, clID

        if profiles == [] or profiles == {}:
            profiles = bs.getConfig()['Player Profiles']

	def getTag(*args):
		  #if alreadyHasTag: return True
		  #profiles = self._player.getInputDevice()._getPlayerProfiles()
		  for p in profiles:
		    if '/tag' in p:
		     try:
			      tag = p.split(' ')[1]
			      if '\\' in tag:
				#print tag + ' before'
				tag =tag.replace('\d','\ue048'.decode('unicode-escape'))
				tag =tag.replace('\c','\ue043'.decode('unicode-escape'))
				tag =tag.replace('\h','\ue049'.decode('unicode-escape'))
				tag =tag.replace('\s','\ue046'.decode('unicode-escape'))
				tag =tag.replace('\\n','\ue04b'.decode('unicode-escape'))
				tag =tag.replace('\\f','\ue04f'.decode('unicode-escape'))
			      	#print tag + ' after'		
			      return tag
		     except:
			pass   
		  return '0'

        try:
		if cl_str in gph.effectCustomers:
			effect = gph.effectCustomers[cl_str]["effect"]
			if effect == 'ice':
				self.snowTimer = bs.Timer(500, bs.WeakCall(self.emitIce), repeat=True)
			elif effect == 'sweat':
				self.smokeTimer = bs.Timer(40, bs.WeakCall(self.emitSmoke), repeat=True)
			elif effect == 'scorch':
				self.scorchTimer = bs.Timer(500, bs.WeakCall(self.update_Scorch), repeat=True)
			elif effect == 'glow':
				self.addLightColor((1, 0.6, 0.4));self.checkDeadTimer = bs.Timer(150, bs.WeakCall(self.checkPlayerifDead), repeat=True)
			elif effect == 'distortion':
				self.DistortionTimer = bs.Timer(1000, bs.WeakCall(self.emitDistortion), repeat=True)
			elif effect == 'slime':
				self.slimeTimer = bs.Timer(250, bs.WeakCall(self.emitSlime), repeat=True)
			elif effect == 'metal':
				self.metalTimer = bs.Timer(500, bs.WeakCall(self.emitMetal), repeat=True)
			elif effect == 'surrounder':
				self.surround = SurroundBall(spaz, shape="bones")
                elif cl_str in gph.surroundingObjectEffect:
		    self.surround = SurroundBall(spaz, shape="bones")
		    flag = 1
                elif cl_str in gph.sparkEffect:
                    self.sparkTimer = bs.Timer(100, bs.WeakCall(self.emitSpark), repeat=True)
		    flag = 1
                elif cl_str in gph.smokeEffect:
		    self.smokeTimer = bs.Timer(40, bs.WeakCall(self.emitSmoke), repeat=True)
		    flag = 1
                elif cl_str in gph.scorchEffect:
		    self.scorchTimer = bs.Timer(500, bs.WeakCall(self.update_Scorch), repeat=True)
		    flag = 1
                elif cl_str in gph.distortionEffect:
		    self.DistortionTimer = bs.Timer(1000, bs.WeakCall(self.emitDistortion), repeat=True)
		    flag = 1
                elif cl_str in gph.glowEffect:
		    self.addLightColor((1, 0.6, 0.4));self.checkDeadTimer = bs.Timer(150, bs.WeakCall(self.checkPlayerifDead), repeat=True)
		    flag = 1
                elif cl_str in gph.iceEffect:
		    self.snowTimer = bs.Timer(500, bs.WeakCall(self.emitIce), repeat=True)
		    flag = 1
                elif cl_str in gph.slimeEffect:
		    self.slimeTimer = bs.Timer(250, bs.WeakCall(self.emitSlime), repeat=True)
		    flag = 1
                elif cl_str in gph.metalEffect:
		    self.metalTimer = bs.Timer(500, bs.WeakCall(self.emitMetal), repeat=True)
		    flag = 1
	
		if cl_str in gph.customlist:
			    PermissionEffect(owner = spaz.node,prefix =gph.customlist[cl_str],prefixAnim = {0: (1,0,0), 250: (0,1,0),250*2:(0,0,1),250*3:(1,0,0)})
                elif cl_str in gph.customtagHashes:
			    tag = getTag(1)
			    if tag == '0': tag = u'#Pro'
			    PermissionEffect(owner = spaz.node,prefix = tag,prefixAnim = {0: (1,0,0), 250: (0,1,0),250*2:(0,0,1),250*3:(1,0,0)})
                elif cl_str in gph.ownerHashes:
			    tag = getTag(1)
			    if tag == '0': tag = u'#Lord'
			    PermissionEffect(owner = spaz.node,prefix = tag,prefixAnim = {0: (1,0,0), 250: (0,1,0),250*2:(0,0,1),250*3:(1,0,0)}, prefixAnimate = True, particles = True)
                elif cl_str in gph.adminHashes:
			    tag = getTag(1)
			    if tag == '0': tag = u'#Mod'
			    PermissionEffect(owner = spaz.node,prefix = tag,prefixAnim = {0: (1,0,0), 250: (0,1,0),250*2:(0,0,1),250*3:(1,0,0)})
                elif cl_str in gph.vipHashes:	
			    tag = getTag(1)
			    if tag == '0': tag = u'#Vip'
			    PermissionEffect(owner = spaz.node,prefix = tag,prefixAnim = {0: (1,0,0), 250: (0,1,0),250*2:(0,0,1),250*3:(1,0,0)})
        except:
                pass


    """if "smoke" and "spark" and "snowDrops" and "slimeDrops" and "metalDrops" and "Distortion" and "neroLight" and "scorch" and "HealTimer" and "KamikazeCheck" not in self.Decorations:
                    #self.checkDeadTimer = bs.Timer(150, bs.WeakCall(self.checkPlayerifDead), repeat=True)
            
                    if self.sourcePlayer.isAlive() and isinstance(self.sourcePlayer.actor,bs.PlayerSpaz) and self.sourcePlayer.actor.node.exists():
                        #print("OK")
                        self.sourcePlayer.actor.node.addDeathAction(bs.Call(self.handleMessage,bs.DieMessage()))
            """

    def checkPlayerifDead(self):
        spaz = self.spazRef()
        if spaz is None or not spaz.isAlive() or not spaz.node.exists():
            self.checkDeadTimer = None
            self.handleMessage(bs.DieMessage())
            return
    def update_Scorch(self):
        spaz = self.spazRef()
        if spaz is not None and spaz.isAlive() and spaz.node.exists():
            color = (random.random(),random.random(),random.random())
            if not hasattr(self,"scorchNode") or self.scorchNode == None:
                self.scorchNode = None
                self.scorchNode = bs.newNode("scorch",attrs={"position":(spaz.node.position),"size":1.17,"big":True})
                spaz.node.connectAttr("position",self.scorchNode,"position")
            bsUtils.animateArray(self.scorchNode,"color",3,{0:self.scorchNode.color,500:color})
        else:
            self.scorchTimer = None
            self.scorchNode.delete()
            self.handleMessage(bs.DieMessage())
        
    def neonLightSwitch(self,shine,Highlight,NameColor):
        spaz = self.spazRef()
        if spaz is not None and spaz.isAlive() and spaz.node.exists():
            color = (random.random(),random.random(),random.random())
            if NameColor:
                bsUtils.animateArray(spaz.node,"nameColor",3,{0:spaz.node.nameColor,500:bs.getSafeColor(color)})
            if shine:color = tuple([min(10., 10 * x) for x in color])
            bsUtils.animateArray(spaz.node,"color",3,{0:spaz.node.color,500:color})
            if Highlight:
                #print spaz.node.highlight
                color = (random.random(),random.random(),random.random())
                if shine:color = tuple([min(10., 10 * x) for x in color])
                bsUtils.animateArray(spaz.node,"highlight",3,{0:spaz.node.highlight,500:color})
        else:
            self.neroLightTimer = None
            self.handleMessage(bs.DieMessage())

 
    def addLightColor(self, color):
        self.light = bs.newNode("light", attrs={"color": color,
                                                "heightAttenuated": False,
                                                "radius": 0.4})
        self.spazRef().node.connectAttr("position", self.light, "position")
        bsUtils.animate(self.light, "intensity", {0: 0.1, 250: 0.3, 500: 0.1}, loop=True)
        
    def emitDistortion(self):
        spaz = self.spazRef()
        if spaz is None or not spaz.isAlive() or not spaz.node.exists():
            self.handleMessage(bs.DieMessage())
            return
        bs.emitBGDynamics(position=spaz.node.position,emitType="distortion",spread=1.0)
        bs.emitBGDynamics(position=spaz.node.position, velocity=spaz.node.velocity,count=random.randint(1,5),emitType="tendrils",tendrilType="smoke")

        
    def emitSpark(self):
        spaz = self.spazRef()
        if spaz is None or not spaz.isAlive() or not spaz.node.exists():
            self.handleMessage(bs.DieMessage())
            return
        bs.emitBGDynamics(position=spaz.node.position, velocity=spaz.node.velocity, count=random.randint(1,10), scale=2, spread=0.2,
                          chunkType="spark")
    def emitIce(self):
        spaz = self.spazRef()
        if spaz is None or not spaz.isAlive() or not spaz.node.exists():
            self.handleMessage(bs.DieMessage())
            return
        bs.emitBGDynamics(position=spaz.node.position , velocity=spaz.node.velocity, count=random.randint(2,8), scale=0.4, spread=0.2,
                          chunkType="ice")
    def emitSmoke(self):
        spaz = self.spazRef()
        if spaz is None or not spaz.isAlive() or not spaz.node.exists():
            self.handleMessage(bs.DieMessage())
            return
        bs.emitBGDynamics(position=spaz.node.position, velocity=spaz.node.velocity, count=random.randint(1,10), scale=2, spread=0.2,
                          chunkType="sweat")
    def emitSlime(self):
        spaz = self.spazRef()
        if spaz is None or not spaz.isAlive() or not spaz.node.exists():
            self.handleMessage(bs.DieMessage())
            return
        bs.emitBGDynamics(position=spaz.node.position , velocity=spaz.node.velocity, count=random.randint(1,10), scale=0.4, spread=0.2,
                          chunkType="slime")
    def emitMetal(self):
        spaz = self.spazRef()
        if spaz is None or not spaz.isAlive() or not spaz.node.exists():
            self.handleMessage(bs.DieMessage())
            return
        bs.emitBGDynamics(position=spaz.node.position, velocity=spaz.node.velocity, count=random.randint(2,8), scale=0.4, spread=0.2,
                          chunkType="metal")
    def handleMessage(self, m):
        #self._handleMessageSanityCheck()
        
        if isinstance(m, bs.OutOfBoundsMessage):
            self.handleMessage(bs.DieMessage())
        elif isinstance(m, bs.DieMessage):
            if hasattr(self,"light") and self.light is not None:self.light.delete()
            if hasattr(self,"smokeTimer"):self.smokeTimer = None
            if hasattr(self,"surround"):self.surround = None
            if hasattr(self,"sparkTimer"):self.sparkTimer = None
            if hasattr(self,"snowTimer"):self.snowTimer = None
            if hasattr(self,"metalTimer"):self.metalTimer = None
            if hasattr(self,"DistortionTimer"):self.DistortionTimer = None
            if hasattr(self,"slimeTimer"):self.slimeTimer = None
            if hasattr(self,"KamikazeCheck"):self.KamikazeCheck = None
            if hasattr(self,"neroLightTimer"):self.neroLightTimer = None
            if hasattr(self,"checkDeadTimer"):self.checkDeadTimer = None
            if hasattr(self,"HealTimer"):self.HealTimer = None
            if hasattr(self,"scorchTimer"):self.scorchTimer = None
            if hasattr(self,"scorchNode"):self.scorchNode = None
            if not self._hasDead:
                spaz = self.spazRef()
                #print str(spaz) + "Spaz"
                if spaz is not None and spaz.isAlive() and spaz.node.exists():
                    spaz.node.color = self.spazNormalColor
                killer = spaz.lastPlayerAttackedBy if spaz is not None else None
                try:
                    if killer in (None,bs.Player(None)) or killer.actor is None or not killer.actor.exists() or killer.actor.hitPoints <= 0:killer = None
                except:killer = None
                #if hasattr(self,"hasDead") and not self.hasDead:
                
                self._hasDead = True
            
        bs.Actor.handleMessage(self, m)


def _Modify_BS_PlayerSpaz__init__(self, color=(1, 1, 1), highlight=(0.5, 0.5, 0.5), character="Spaz", player=None,
                           powerupsExpire=True):
    if player is None: player = bs.Player(None)

    bsSpaz.Spaz.__init__(self, color=color, highlight=highlight, character=character, sourcePlayer=player,
                     startInvincible=True, powerupsExpire=powerupsExpire)
    self.lastPlayerAttackedBy = None  # FIXME - should use empty player ref
    self.lastAttackedTime = 0
    self.lastAttackedType = None
    self.heldCount = 0
    self.lastPlayerHeldBy = None  # FIXME - should use empty player ref here
    self._player = player


    playeraccountid=self._player.get_account_id()
    if os.path.exists(bs.getEnvironment()['systemScriptsDirectory'] + "/stats.json"):
        while True:
            try:
                with open(bs.getEnvironment()['systemScriptsDirectory'] + '/stats.json', 'r') as f:
                    stats = json.loads(f.read())
                    break
            except Exception as (e):
                print e
                time.sleep(0.05)
    else:
        stats = {}
    if playeraccountid not in stats:
        killed=1
        kills=0
    else:    
        killed=stats[playeraccountid]['deaths']
        kills=stats[playeraccountid]['kills']
        if(killed==0):
            killed=1
    kd=kills/round(killed,1)
    kd=round(kd,3)
    kd=float(kd)
    ranked=False
    #print("kill",kills,"killed",killed,"kd",round(kd,3))
    
    ##v
    reload(rank)
    if playeraccountid in rank.player:
      
      prank=rank.player.index(playeraccountid)+1
      ranked=True
      
    if ranked:
        PermissionEffect(owner = self.node,prank=prank,prefix = " #"+str(prank),prefixAnim = {0: (0.85,0.852,0.85), 250: (0.59,0.598,0),250*2:(0.75,1,0),250*3:(0.9,0.17,0.028)},prefixAnimate =False, particles = False, type = 2)
        PermissionEffect(owner = self.node,kd=kd,prefix = " K.D: "+str(kd),prefixAnim = {0: (0.85,0.852,0.85), 250: (0.59,0.598,0),250*2:(0.75,1,0),250*3:(0.9,0.17,0.028)},prefixAnimate =False, particles = False, type = 4)
        kdpronoobtag(owner = self.node,kd=kd,kills=kills,prefix = " ",prefixAnim = {0: (0.85,0.852,0.85), 250: (0.59,0.598,0),250*2:(0.75,1,0),250*3:(0.9,0.17,0.028)},prefixAnimate =False, particles = False)

    # grab the node for this player and wire it to follow our spaz (so players" controllers know where to draw their guides, etc)
    if player.exists():
        playerNode = bs.getActivity()._getPlayerNode(player)
        self.node.connectAttr("torsoPosition", playerNode, "position")
    



    """"if aid in gph.vipHashes:
        colors = {0: (0, 0, 4), 500: (0, 4, 0),1000: (4, 0, 0), 1500: (0, 0, 4)}
        highlights = {0: (4, 0, 0), 500: (0, 0, 0),1000: (0, 0, 4), 1500: (4, 0, 0)}
        bsUtils.animateArray(self.node, 'color', 3, colors, True)
        bsUtils.animateArray(self.node, 'highlight', 3, highlights, True)"""

    """if playeraccountid in gph.ownerHashes
        self.modpack = bs.NodeActor(bs.newNode('text',
                                              attrs={'vAttach':'bottom',
                                                     'hAttach':'right',
                                                     'hAlign':'right',
                                                     'color':(1,1,1),
                                                     'flatness':1.0,
                                                     'shadow':1.0,
                                                     'scale':0.85,
                                                     'position':(-200,5),
                                                     'text':u'El Creador a ingresado'}))"""


    self.lastPos = self.node.position
    if playeraccountid in gph.ownerHashes:

        def doCirle():
            if self.isAlive():
                p = self.node.position
                p2 = self.lastPos
                diff = (bs.Vector(p[0] - p2[0], 0.0, p[2] - p2[2]))
                dist = (diff.length())
                if dist > 0.2:
                    c = self.node.highlight
                    r = bs.newNode('locator',
                                   attrs={
                                       'shape': 'circle',
                                       'position': p,
                                       'color': self.node.color if c else
                                       (5, 5, 5),
                                       'opacity': 1,
                                       'drawBeauty': False,
                                       'additive': False,
                                       'size': [0.2]
                                   })
                    bsUtils.animateArray(r, 'size', 1, {
                        0: [0.2],
                        2500: [0.2],
                        3000: [0]
                    })
                    bs.gameTimer(3000, r.delete)
                    self.lastPos = self.node.position

        bs.gameTimer(200, bs.Call(doCirle), repeat=True)

        def getPos():
            return self.node.position



    self.HasEnhanced = False
    self.Enhancement = Enhancement(self, self.sourcePlayer).autoRetain()
ub.append(id)
bsSpaz.PlayerSpaz.__init__ = _Modify_BS_PlayerSpaz__init__



