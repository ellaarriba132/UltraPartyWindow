# place any of your own overrides here225944
# see bombsquad_server for details on what you can override
# examples (uncomment to use):
config['partyName'] = u'|\ue00cSempai\ue00c| Super Smash FFA'
config['sessionType'] = 'ffa'
config['maxPartySize'] = 11
#config['port'] = 38308
config['partyIsPublic'] = True
config['playlistCode'] = 340676
config['statsURL'] = ''
config['enableTelnet'] = True
config['telnetPassword'] = 'broody'
config['telnetPort'] = 43211
